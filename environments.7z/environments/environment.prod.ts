export const environment = {
  production: true,
  serverURL: "https://us-central1-toodlyco.cloudfunctions.net/api",
  firebase: {
    apiKey: "AIzaSyBRR2eqsaCIuEkIcDQkJca1iKva_Y8jrec",
    authDomain: "toodlyco.firebaseapp.com",
    databaseURL: "https://toodlyco.firebaseio.com",
    projectId: "toodlyco",
    storageBucket: "toodlyco.appspot.com",
    messagingSenderId: "176360449015",
    appId: "1:176360449015:web:98c1c332d2263ce6f784f2"
  }
};
